const searchInput = document.getElementById("searchInput");
const productList = document.getElementById("productList");
const products = productList.getElementsByClassName("product");
const noResult = document.getElementById("noResult");

searchInput.addEventListener("keyup", function () {
    let text = searchInput.value.toLowerCase();
    let matchFound = false;

    for (let i = 0; i < products.length; i++) {
        let name = products[i].getElementsByTagName("h3")[0].innerText.toLowerCase();

        if (name.includes(text)) {
            products[i].style.display = "block";
            matchFound = true;
        } else {
            products[i].style.display = "none";
        }
    }

    if (matchFound) {
        noResult.classList.add("hidden");
    } else {
        noResult.classList.remove("hidden");
    }
});